# Endocrine Calculator Android App

This is a lightweight Android app that packages the endocrine calculator as an offline WebView application.

## Open in Android Studio

1. Open this folder in Android Studio:
   `C:\Users\drjk2\Documents\Codex\2026-05-25\files-mentioned-by-the-user-endocrine`
2. Let Gradle sync.
3. Click **Run** to install it on an emulator or Android device.

## Build APK

From Android Studio, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

If Gradle is available on your PATH, you can also run:

```powershell
gradle assembleDebug
```

The debug APK will be created under:

```text
app\build\outputs\apk\debug\
```

## Build APK Online With GitHub

If you do not have Android Studio or Android build tools:

1. Create a new GitHub repository.
2. Upload all files from this folder to that repository.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**.
5. Click **Run workflow**.
6. When the workflow finishes, open the completed run and download the artifact named:
   `EndocrineCalculator-debug-apk`

Inside the downloaded ZIP is:

```text
EndocrineCalculator-debug.apk
```

Transfer that APK to your Android phone and install it. You may need to allow installation from unknown sources.

## Install Online as a Web App

The `web` folder contains a Progressive Web App version. Upload the contents of `web` to any static host such as GitHub Pages, Netlify, Vercel, or Firebase Hosting. On Android Chrome, open the hosted URL and choose **Add to Home screen** or **Install app**.

## Notes

The calculator data in `app/src/main/assets/index.html` still contains the sample LMS values from the original HTML. Replace those reference values with the full WHO/IAP dataset before using the SDS module clinically.
